package com.example.finaltask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
       // ed1 = (TextView) findViewById(R.id.txt_2);
       // String dato = getIntent().getStringExtra("data");
       // ed1.setText(dato);
    }
}